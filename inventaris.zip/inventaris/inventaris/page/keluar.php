<?php
    session_start();
    session_destroy();

    ?>
    <script type="text/javascript" >
        window.location.href="../index.php?p=login";
    </script>
    <?php
?>